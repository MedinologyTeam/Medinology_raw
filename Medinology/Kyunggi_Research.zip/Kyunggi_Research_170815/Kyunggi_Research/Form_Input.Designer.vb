﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_Input
    Inherits System.Windows.Forms.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기에서는 수정하지 마세요.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button_OK = New System.Windows.Forms.Button()
        Me.GroupBox_Person = New System.Windows.Forms.GroupBox()
        Me.Label_Age2 = New System.Windows.Forms.Label()
        Me.NumericUpDown_Age = New System.Windows.Forms.NumericUpDown()
        Me.Label_Age = New System.Windows.Forms.Label()
        Me.RadioButton_Female = New System.Windows.Forms.RadioButton()
        Me.Label_Gender = New System.Windows.Forms.Label()
        Me.RadioButton_Male = New System.Windows.Forms.RadioButton()
        Me.GroupBox_Pregnancy = New System.Windows.Forms.GroupBox()
        Me.RadioButton_PregF = New System.Windows.Forms.RadioButton()
        Me.RadioButton_PregT = New System.Windows.Forms.RadioButton()
        Me.GroupBox_Symptom = New System.Windows.Forms.GroupBox()
        Me.CheckBox51 = New System.Windows.Forms.CheckBox()
        Me.CheckBox50 = New System.Windows.Forms.CheckBox()
        Me.CheckBox49 = New System.Windows.Forms.CheckBox()
        Me.CheckBox48 = New System.Windows.Forms.CheckBox()
        Me.CheckBox47 = New System.Windows.Forms.CheckBox()
        Me.CheckBox46 = New System.Windows.Forms.CheckBox()
        Me.CheckBox45 = New System.Windows.Forms.CheckBox()
        Me.CheckBox44 = New System.Windows.Forms.CheckBox()
        Me.CheckBox43 = New System.Windows.Forms.CheckBox()
        Me.CheckBox42 = New System.Windows.Forms.CheckBox()
        Me.CheckBox41 = New System.Windows.Forms.CheckBox()
        Me.CheckBox40 = New System.Windows.Forms.CheckBox()
        Me.CheckBox39 = New System.Windows.Forms.CheckBox()
        Me.CheckBox38 = New System.Windows.Forms.CheckBox()
        Me.CheckBox37 = New System.Windows.Forms.CheckBox()
        Me.CheckBox36 = New System.Windows.Forms.CheckBox()
        Me.CheckBox35 = New System.Windows.Forms.CheckBox()
        Me.CheckBox34 = New System.Windows.Forms.CheckBox()
        Me.CheckBox33 = New System.Windows.Forms.CheckBox()
        Me.CheckBox32 = New System.Windows.Forms.CheckBox()
        Me.CheckBox31 = New System.Windows.Forms.CheckBox()
        Me.CheckBox30 = New System.Windows.Forms.CheckBox()
        Me.CheckBox29 = New System.Windows.Forms.CheckBox()
        Me.CheckBox28 = New System.Windows.Forms.CheckBox()
        Me.CheckBox27 = New System.Windows.Forms.CheckBox()
        Me.CheckBox26 = New System.Windows.Forms.CheckBox()
        Me.CheckBox25 = New System.Windows.Forms.CheckBox()
        Me.CheckBox24 = New System.Windows.Forms.CheckBox()
        Me.CheckBox23 = New System.Windows.Forms.CheckBox()
        Me.CheckBox22 = New System.Windows.Forms.CheckBox()
        Me.CheckBox21 = New System.Windows.Forms.CheckBox()
        Me.CheckBox20 = New System.Windows.Forms.CheckBox()
        Me.CheckBox19 = New System.Windows.Forms.CheckBox()
        Me.CheckBox18 = New System.Windows.Forms.CheckBox()
        Me.CheckBox17 = New System.Windows.Forms.CheckBox()
        Me.CheckBox16 = New System.Windows.Forms.CheckBox()
        Me.CheckBox15 = New System.Windows.Forms.CheckBox()
        Me.CheckBox14 = New System.Windows.Forms.CheckBox()
        Me.CheckBox13 = New System.Windows.Forms.CheckBox()
        Me.CheckBox12 = New System.Windows.Forms.CheckBox()
        Me.CheckBox11 = New System.Windows.Forms.CheckBox()
        Me.CheckBox10 = New System.Windows.Forms.CheckBox()
        Me.CheckBox9 = New System.Windows.Forms.CheckBox()
        Me.CheckBox8 = New System.Windows.Forms.CheckBox()
        Me.CheckBox7 = New System.Windows.Forms.CheckBox()
        Me.CheckBox6 = New System.Windows.Forms.CheckBox()
        Me.CheckBox5 = New System.Windows.Forms.CheckBox()
        Me.CheckBox4 = New System.Windows.Forms.CheckBox()
        Me.CheckBox3 = New System.Windows.Forms.CheckBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.GroupBox_MedicalHistory = New System.Windows.Forms.GroupBox()
        Me.CheckBox_His11 = New System.Windows.Forms.CheckBox()
        Me.CheckBox_His10 = New System.Windows.Forms.CheckBox()
        Me.CheckBox_His09 = New System.Windows.Forms.CheckBox()
        Me.CheckBox_His08 = New System.Windows.Forms.CheckBox()
        Me.CheckBox_His07 = New System.Windows.Forms.CheckBox()
        Me.CheckBox_His06 = New System.Windows.Forms.CheckBox()
        Me.CheckBox_His05 = New System.Windows.Forms.CheckBox()
        Me.CheckBox_His04 = New System.Windows.Forms.CheckBox()
        Me.CheckBox_His03 = New System.Windows.Forms.CheckBox()
        Me.CheckBox_His02 = New System.Windows.Forms.CheckBox()
        Me.CheckBox_His01 = New System.Windows.Forms.CheckBox()
        Me.GroupBox_Medicine = New System.Windows.Forms.GroupBox()
        Me.CheckBox_Medi11 = New System.Windows.Forms.CheckBox()
        Me.CheckBox_Medi10 = New System.Windows.Forms.CheckBox()
        Me.CheckBox_Medi09 = New System.Windows.Forms.CheckBox()
        Me.CheckBox_Medi08 = New System.Windows.Forms.CheckBox()
        Me.CheckBox_Medi07 = New System.Windows.Forms.CheckBox()
        Me.CheckBox_Medi06 = New System.Windows.Forms.CheckBox()
        Me.CheckBox_Medi05 = New System.Windows.Forms.CheckBox()
        Me.CheckBox_Medi04 = New System.Windows.Forms.CheckBox()
        Me.CheckBox_Medi03 = New System.Windows.Forms.CheckBox()
        Me.CheckBox_Medi02 = New System.Windows.Forms.CheckBox()
        Me.CheckBox_Medi01 = New System.Windows.Forms.CheckBox()
        Me.GroupBox_Person.SuspendLayout()
        CType(Me.NumericUpDown_Age, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Pregnancy.SuspendLayout()
        Me.GroupBox_Symptom.SuspendLayout()
        Me.GroupBox_MedicalHistory.SuspendLayout()
        Me.GroupBox_Medicine.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button_OK
        '
        Me.Button_OK.Font = New System.Drawing.Font("돋움", 9.0!)
        Me.Button_OK.Location = New System.Drawing.Point(847, 497)
        Me.Button_OK.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button_OK.Name = "Button_OK"
        Me.Button_OK.Size = New System.Drawing.Size(125, 41)
        Me.Button_OK.TabIndex = 0
        Me.Button_OK.Text = "확인"
        Me.Button_OK.UseVisualStyleBackColor = True
        '
        'GroupBox_Person
        '
        Me.GroupBox_Person.Controls.Add(Me.Label_Age2)
        Me.GroupBox_Person.Controls.Add(Me.NumericUpDown_Age)
        Me.GroupBox_Person.Controls.Add(Me.Label_Age)
        Me.GroupBox_Person.Controls.Add(Me.RadioButton_Female)
        Me.GroupBox_Person.Controls.Add(Me.Label_Gender)
        Me.GroupBox_Person.Controls.Add(Me.RadioButton_Male)
        Me.GroupBox_Person.Location = New System.Drawing.Point(12, 15)
        Me.GroupBox_Person.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_Person.Name = "GroupBox_Person"
        Me.GroupBox_Person.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_Person.Size = New System.Drawing.Size(475, 156)
        Me.GroupBox_Person.TabIndex = 1
        Me.GroupBox_Person.TabStop = False
        Me.GroupBox_Person.Text = "기본 정보"
        '
        'Label_Age2
        '
        Me.Label_Age2.AutoSize = True
        Me.Label_Age2.Location = New System.Drawing.Point(265, 108)
        Me.Label_Age2.Name = "Label_Age2"
        Me.Label_Age2.Size = New System.Drawing.Size(142, 15)
        Me.Label_Age2.TabIndex = 5
        Me.Label_Age2.Text = "( 만 나이로 입력하세요. )"
        '
        'NumericUpDown_Age
        '
        Me.NumericUpDown_Age.Location = New System.Drawing.Point(98, 104)
        Me.NumericUpDown_Age.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.NumericUpDown_Age.Maximum = New Decimal(New Integer() {256, 0, 0, 0})
        Me.NumericUpDown_Age.Name = "NumericUpDown_Age"
        Me.NumericUpDown_Age.Size = New System.Drawing.Size(53, 23)
        Me.NumericUpDown_Age.TabIndex = 4
        Me.NumericUpDown_Age.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_Age
        '
        Me.Label_Age.AutoSize = True
        Me.Label_Age.Location = New System.Drawing.Point(17, 108)
        Me.Label_Age.Name = "Label_Age"
        Me.Label_Age.Size = New System.Drawing.Size(38, 15)
        Me.Label_Age.TabIndex = 3
        Me.Label_Age.Text = "나이 :"
        '
        'RadioButton_Female
        '
        Me.RadioButton_Female.AutoSize = True
        Me.RadioButton_Female.Location = New System.Drawing.Point(270, 36)
        Me.RadioButton_Female.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.RadioButton_Female.Name = "RadioButton_Female"
        Me.RadioButton_Female.Size = New System.Drawing.Size(49, 19)
        Me.RadioButton_Female.TabIndex = 2
        Me.RadioButton_Female.TabStop = True
        Me.RadioButton_Female.Text = "여성"
        Me.RadioButton_Female.UseVisualStyleBackColor = True
        '
        'Label_Gender
        '
        Me.Label_Gender.AutoSize = True
        Me.Label_Gender.Location = New System.Drawing.Point(17, 39)
        Me.Label_Gender.Name = "Label_Gender"
        Me.Label_Gender.Size = New System.Drawing.Size(38, 15)
        Me.Label_Gender.TabIndex = 1
        Me.Label_Gender.Text = "성별 :"
        '
        'RadioButton_Male
        '
        Me.RadioButton_Male.AutoSize = True
        Me.RadioButton_Male.Location = New System.Drawing.Point(98, 36)
        Me.RadioButton_Male.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.RadioButton_Male.Name = "RadioButton_Male"
        Me.RadioButton_Male.Size = New System.Drawing.Size(49, 19)
        Me.RadioButton_Male.TabIndex = 0
        Me.RadioButton_Male.TabStop = True
        Me.RadioButton_Male.Text = "남성"
        Me.RadioButton_Male.UseVisualStyleBackColor = True
        '
        'GroupBox_Pregnancy
        '
        Me.GroupBox_Pregnancy.Controls.Add(Me.RadioButton_PregF)
        Me.GroupBox_Pregnancy.Controls.Add(Me.RadioButton_PregT)
        Me.GroupBox_Pregnancy.Location = New System.Drawing.Point(12, 179)
        Me.GroupBox_Pregnancy.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_Pregnancy.Name = "GroupBox_Pregnancy"
        Me.GroupBox_Pregnancy.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_Pregnancy.Size = New System.Drawing.Size(475, 75)
        Me.GroupBox_Pregnancy.TabIndex = 2
        Me.GroupBox_Pregnancy.TabStop = False
        Me.GroupBox_Pregnancy.Text = "임신 여부"
        '
        'RadioButton_PregF
        '
        Me.RadioButton_PregF.AutoSize = True
        Me.RadioButton_PregF.Location = New System.Drawing.Point(270, 31)
        Me.RadioButton_PregF.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.RadioButton_PregF.Name = "RadioButton_PregF"
        Me.RadioButton_PregF.Size = New System.Drawing.Size(61, 19)
        Me.RadioButton_PregF.TabIndex = 4
        Me.RadioButton_PregF.TabStop = True
        Me.RadioButton_PregF.Text = "아니오"
        Me.RadioButton_PregF.UseVisualStyleBackColor = True
        '
        'RadioButton_PregT
        '
        Me.RadioButton_PregT.AutoSize = True
        Me.RadioButton_PregT.Location = New System.Drawing.Point(98, 31)
        Me.RadioButton_PregT.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.RadioButton_PregT.Name = "RadioButton_PregT"
        Me.RadioButton_PregT.Size = New System.Drawing.Size(37, 19)
        Me.RadioButton_PregT.TabIndex = 3
        Me.RadioButton_PregT.TabStop = True
        Me.RadioButton_PregT.Text = "예"
        Me.RadioButton_PregT.UseVisualStyleBackColor = True
        '
        'GroupBox_Symptom
        '
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox51)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox50)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox49)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox48)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox47)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox46)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox45)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox44)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox43)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox42)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox41)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox40)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox39)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox38)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox37)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox36)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox35)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox34)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox33)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox32)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox31)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox30)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox29)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox28)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox27)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox26)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox25)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox24)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox23)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox22)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox21)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox20)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox19)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox18)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox17)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox16)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox15)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox14)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox13)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox12)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox11)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox10)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox9)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox8)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox7)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox6)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox5)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox4)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox3)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox2)
        Me.GroupBox_Symptom.Controls.Add(Me.CheckBox1)
        Me.GroupBox_Symptom.Location = New System.Drawing.Point(497, 15)
        Me.GroupBox_Symptom.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_Symptom.Name = "GroupBox_Symptom"
        Me.GroupBox_Symptom.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_Symptom.Size = New System.Drawing.Size(475, 331)
        Me.GroupBox_Symptom.TabIndex = 5
        Me.GroupBox_Symptom.TabStop = False
        Me.GroupBox_Symptom.Text = "나타나는 증상"
        '
        'CheckBox51
        '
        Me.CheckBox51.AutoSize = True
        Me.CheckBox51.Location = New System.Drawing.Point(388, 190)
        Me.CheckBox51.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox51.Name = "CheckBox51"
        Me.CheckBox51.Size = New System.Drawing.Size(50, 19)
        Me.CheckBox51.TabIndex = 50
        Me.CheckBox51.Text = "흉통"
        Me.CheckBox51.UseVisualStyleBackColor = True
        '
        'CheckBox50
        '
        Me.CheckBox50.AutoSize = True
        Me.CheckBox50.Location = New System.Drawing.Point(388, 162)
        Me.CheckBox50.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox50.Name = "CheckBox50"
        Me.CheckBox50.Size = New System.Drawing.Size(50, 19)
        Me.CheckBox50.TabIndex = 49
        Me.CheckBox50.Text = "황달"
        Me.CheckBox50.UseVisualStyleBackColor = True
        '
        'CheckBox49
        '
        Me.CheckBox49.AutoSize = True
        Me.CheckBox49.Location = New System.Drawing.Point(388, 135)
        Me.CheckBox49.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox49.Name = "CheckBox49"
        Me.CheckBox49.Size = New System.Drawing.Size(50, 19)
        Me.CheckBox49.TabIndex = 48
        Me.CheckBox49.Text = "홍반"
        Me.CheckBox49.UseVisualStyleBackColor = True
        '
        'CheckBox48
        '
        Me.CheckBox48.AutoSize = True
        Me.CheckBox48.Location = New System.Drawing.Point(388, 108)
        Me.CheckBox48.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox48.Name = "CheckBox48"
        Me.CheckBox48.Size = New System.Drawing.Size(74, 19)
        Me.CheckBox48.TabIndex = 47
        Me.CheckBox48.Text = "호흡곤란"
        Me.CheckBox48.UseVisualStyleBackColor = True
        '
        'CheckBox47
        '
        Me.CheckBox47.AutoSize = True
        Me.CheckBox47.Location = New System.Drawing.Point(388, 80)
        Me.CheckBox47.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox47.Name = "CheckBox47"
        Me.CheckBox47.Size = New System.Drawing.Size(50, 19)
        Me.CheckBox47.TabIndex = 46
        Me.CheckBox47.Text = "혈변"
        Me.CheckBox47.UseVisualStyleBackColor = True
        '
        'CheckBox46
        '
        Me.CheckBox46.AutoSize = True
        Me.CheckBox46.Location = New System.Drawing.Point(388, 52)
        Me.CheckBox46.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox46.Name = "CheckBox46"
        Me.CheckBox46.Size = New System.Drawing.Size(62, 19)
        Me.CheckBox46.TabIndex = 45
        Me.CheckBox46.Text = "피부통"
        Me.CheckBox46.UseVisualStyleBackColor = True
        '
        'CheckBox45
        '
        Me.CheckBox45.AutoSize = True
        Me.CheckBox45.Location = New System.Drawing.Point(388, 25)
        Me.CheckBox45.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox45.Name = "CheckBox45"
        Me.CheckBox45.Size = New System.Drawing.Size(74, 19)
        Me.CheckBox45.TabIndex = 44
        Me.CheckBox45.Text = "피부병변"
        Me.CheckBox45.UseVisualStyleBackColor = True
        '
        'CheckBox44
        '
        Me.CheckBox44.AutoSize = True
        Me.CheckBox44.Location = New System.Drawing.Point(295, 300)
        Me.CheckBox44.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox44.Name = "CheckBox44"
        Me.CheckBox44.Size = New System.Drawing.Size(50, 19)
        Me.CheckBox44.TabIndex = 43
        Me.CheckBox44.Text = "피로"
        Me.CheckBox44.UseVisualStyleBackColor = True
        '
        'CheckBox43
        '
        Me.CheckBox43.AutoSize = True
        Me.CheckBox43.Location = New System.Drawing.Point(295, 272)
        Me.CheckBox43.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox43.Name = "CheckBox43"
        Me.CheckBox43.Size = New System.Drawing.Size(50, 19)
        Me.CheckBox43.TabIndex = 42
        Me.CheckBox43.Text = "탈수"
        Me.CheckBox43.UseVisualStyleBackColor = True
        '
        'CheckBox42
        '
        Me.CheckBox42.AutoSize = True
        Me.CheckBox42.Location = New System.Drawing.Point(295, 245)
        Me.CheckBox42.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox42.Name = "CheckBox42"
        Me.CheckBox42.Size = New System.Drawing.Size(50, 19)
        Me.CheckBox42.TabIndex = 41
        Me.CheckBox42.Text = "콧물"
        Me.CheckBox42.UseVisualStyleBackColor = True
        '
        'CheckBox41
        '
        Me.CheckBox41.AutoSize = True
        Me.CheckBox41.Location = New System.Drawing.Point(295, 218)
        Me.CheckBox41.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox41.Name = "CheckBox41"
        Me.CheckBox41.Size = New System.Drawing.Size(62, 19)
        Me.CheckBox41.TabIndex = 40
        Me.CheckBox41.Text = "코막힘"
        Me.CheckBox41.UseVisualStyleBackColor = True
        '
        'CheckBox40
        '
        Me.CheckBox40.AutoSize = True
        Me.CheckBox40.Location = New System.Drawing.Point(295, 190)
        Me.CheckBox40.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox40.Name = "CheckBox40"
        Me.CheckBox40.Size = New System.Drawing.Size(50, 19)
        Me.CheckBox40.TabIndex = 39
        Me.CheckBox40.Text = "치질"
        Me.CheckBox40.UseVisualStyleBackColor = True
        '
        'CheckBox39
        '
        Me.CheckBox39.AutoSize = True
        Me.CheckBox39.Location = New System.Drawing.Point(295, 162)
        Me.CheckBox39.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox39.Name = "CheckBox39"
        Me.CheckBox39.Size = New System.Drawing.Size(74, 19)
        Me.CheckBox39.TabIndex = 38
        Me.CheckBox39.Text = "체중감소"
        Me.CheckBox39.UseVisualStyleBackColor = True
        '
        'CheckBox38
        '
        Me.CheckBox38.AutoSize = True
        Me.CheckBox38.Location = New System.Drawing.Point(295, 135)
        Me.CheckBox38.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox38.Name = "CheckBox38"
        Me.CheckBox38.Size = New System.Drawing.Size(74, 19)
        Me.CheckBox38.TabIndex = 37
        Me.CheckBox38.Text = "전신쇠약"
        Me.CheckBox38.UseVisualStyleBackColor = True
        '
        'CheckBox37
        '
        Me.CheckBox37.AutoSize = True
        Me.CheckBox37.Location = New System.Drawing.Point(295, 108)
        Me.CheckBox37.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox37.Name = "CheckBox37"
        Me.CheckBox37.Size = New System.Drawing.Size(62, 19)
        Me.CheckBox37.TabIndex = 36
        Me.CheckBox37.Text = "재채기"
        Me.CheckBox37.UseVisualStyleBackColor = True
        '
        'CheckBox36
        '
        Me.CheckBox36.AutoSize = True
        Me.CheckBox36.Location = New System.Drawing.Point(295, 80)
        Me.CheckBox36.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox36.Name = "CheckBox36"
        Me.CheckBox36.Size = New System.Drawing.Size(62, 19)
        Me.CheckBox36.TabIndex = 35
        Me.CheckBox36.Text = "잔뇨감"
        Me.CheckBox36.UseVisualStyleBackColor = True
        '
        'CheckBox35
        '
        Me.CheckBox35.AutoSize = True
        Me.CheckBox35.Location = New System.Drawing.Point(295, 52)
        Me.CheckBox35.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox35.Name = "CheckBox35"
        Me.CheckBox35.Size = New System.Drawing.Size(74, 19)
        Me.CheckBox35.TabIndex = 34
        Me.CheckBox35.Text = "잇몸출혈"
        Me.CheckBox35.UseVisualStyleBackColor = True
        '
        'CheckBox34
        '
        Me.CheckBox34.AutoSize = True
        Me.CheckBox34.Location = New System.Drawing.Point(295, 25)
        Me.CheckBox34.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox34.Name = "CheckBox34"
        Me.CheckBox34.Size = New System.Drawing.Size(50, 19)
        Me.CheckBox34.TabIndex = 33
        Me.CheckBox34.Text = "이명"
        Me.CheckBox34.UseVisualStyleBackColor = True
        '
        'CheckBox33
        '
        Me.CheckBox33.AutoSize = True
        Me.CheckBox33.Location = New System.Drawing.Point(202, 300)
        Me.CheckBox33.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox33.Name = "CheckBox33"
        Me.CheckBox33.Size = New System.Drawing.Size(50, 19)
        Me.CheckBox33.TabIndex = 32
        Me.CheckBox33.Text = "오한"
        Me.CheckBox33.UseVisualStyleBackColor = True
        '
        'CheckBox32
        '
        Me.CheckBox32.AutoSize = True
        Me.CheckBox32.Location = New System.Drawing.Point(202, 272)
        Me.CheckBox32.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox32.Name = "CheckBox32"
        Me.CheckBox32.Size = New System.Drawing.Size(50, 19)
        Me.CheckBox32.TabIndex = 31
        Me.CheckBox32.Text = "오심"
        Me.CheckBox32.UseVisualStyleBackColor = True
        '
        'CheckBox31
        '
        Me.CheckBox31.AutoSize = True
        Me.CheckBox31.Location = New System.Drawing.Point(202, 245)
        Me.CheckBox31.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox31.Name = "CheckBox31"
        Me.CheckBox31.Size = New System.Drawing.Size(62, 19)
        Me.CheckBox31.TabIndex = 30
        Me.CheckBox31.Text = "식은땀"
        Me.CheckBox31.UseVisualStyleBackColor = True
        '
        'CheckBox30
        '
        Me.CheckBox30.AutoSize = True
        Me.CheckBox30.Location = New System.Drawing.Point(202, 218)
        Me.CheckBox30.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox30.Name = "CheckBox30"
        Me.CheckBox30.Size = New System.Drawing.Size(74, 19)
        Me.CheckBox30.TabIndex = 29
        Me.CheckBox30.Text = "식욕부진"
        Me.CheckBox30.UseVisualStyleBackColor = True
        '
        'CheckBox29
        '
        Me.CheckBox29.AutoSize = True
        Me.CheckBox29.Location = New System.Drawing.Point(202, 190)
        Me.CheckBox29.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox29.Name = "CheckBox29"
        Me.CheckBox29.Size = New System.Drawing.Size(74, 19)
        Me.CheckBox29.TabIndex = 28
        Me.CheckBox29.Text = "소화불량"
        Me.CheckBox29.UseVisualStyleBackColor = True
        '
        'CheckBox28
        '
        Me.CheckBox28.AutoSize = True
        Me.CheckBox28.Location = New System.Drawing.Point(202, 162)
        Me.CheckBox28.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox28.Name = "CheckBox28"
        Me.CheckBox28.Size = New System.Drawing.Size(50, 19)
        Me.CheckBox28.TabIndex = 27
        Me.CheckBox28.Text = "설사"
        Me.CheckBox28.UseVisualStyleBackColor = True
        '
        'CheckBox27
        '
        Me.CheckBox27.AutoSize = True
        Me.CheckBox27.Location = New System.Drawing.Point(202, 135)
        Me.CheckBox27.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox27.Name = "CheckBox27"
        Me.CheckBox27.Size = New System.Drawing.Size(50, 19)
        Me.CheckBox27.TabIndex = 26
        Me.CheckBox27.Text = "빈뇨"
        Me.CheckBox27.UseVisualStyleBackColor = True
        '
        'CheckBox26
        '
        Me.CheckBox26.AutoSize = True
        Me.CheckBox26.Location = New System.Drawing.Point(202, 108)
        Me.CheckBox26.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox26.Name = "CheckBox26"
        Me.CheckBox26.Size = New System.Drawing.Size(50, 19)
        Me.CheckBox26.TabIndex = 25
        Me.CheckBox26.Text = "부종"
        Me.CheckBox26.UseVisualStyleBackColor = True
        '
        'CheckBox25
        '
        Me.CheckBox25.AutoSize = True
        Me.CheckBox25.Location = New System.Drawing.Point(202, 80)
        Me.CheckBox25.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox25.Name = "CheckBox25"
        Me.CheckBox25.Size = New System.Drawing.Size(50, 19)
        Me.CheckBox25.TabIndex = 24
        Me.CheckBox25.Text = "복통"
        Me.CheckBox25.UseVisualStyleBackColor = True
        '
        'CheckBox24
        '
        Me.CheckBox24.AutoSize = True
        Me.CheckBox24.Location = New System.Drawing.Point(202, 52)
        Me.CheckBox24.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox24.Name = "CheckBox24"
        Me.CheckBox24.Size = New System.Drawing.Size(74, 19)
        Me.CheckBox24.TabIndex = 23
        Me.CheckBox24.Text = "벌레물림"
        Me.CheckBox24.UseVisualStyleBackColor = True
        '
        'CheckBox23
        '
        Me.CheckBox23.AutoSize = True
        Me.CheckBox23.Location = New System.Drawing.Point(202, 25)
        Me.CheckBox23.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox23.Name = "CheckBox23"
        Me.CheckBox23.Size = New System.Drawing.Size(62, 19)
        Me.CheckBox23.TabIndex = 22
        Me.CheckBox23.Text = "배뇨통"
        Me.CheckBox23.UseVisualStyleBackColor = True
        '
        'CheckBox22
        '
        Me.CheckBox22.AutoSize = True
        Me.CheckBox22.Location = New System.Drawing.Point(109, 300)
        Me.CheckBox22.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox22.Name = "CheckBox22"
        Me.CheckBox22.Size = New System.Drawing.Size(50, 19)
        Me.CheckBox22.TabIndex = 21
        Me.CheckBox22.Text = "발진"
        Me.CheckBox22.UseVisualStyleBackColor = True
        '
        'CheckBox21
        '
        Me.CheckBox21.AutoSize = True
        Me.CheckBox21.Location = New System.Drawing.Point(109, 272)
        Me.CheckBox21.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox21.Name = "CheckBox21"
        Me.CheckBox21.Size = New System.Drawing.Size(50, 19)
        Me.CheckBox21.TabIndex = 20
        Me.CheckBox21.Text = "발열"
        Me.CheckBox21.UseVisualStyleBackColor = True
        '
        'CheckBox20
        '
        Me.CheckBox20.AutoSize = True
        Me.CheckBox20.Location = New System.Drawing.Point(109, 245)
        Me.CheckBox20.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox20.Name = "CheckBox20"
        Me.CheckBox20.Size = New System.Drawing.Size(50, 19)
        Me.CheckBox20.TabIndex = 19
        Me.CheckBox20.Text = "무좀"
        Me.CheckBox20.UseVisualStyleBackColor = True
        '
        'CheckBox19
        '
        Me.CheckBox19.AutoSize = True
        Me.CheckBox19.Location = New System.Drawing.Point(109, 218)
        Me.CheckBox19.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox19.Name = "CheckBox19"
        Me.CheckBox19.Size = New System.Drawing.Size(50, 19)
        Me.CheckBox19.TabIndex = 18
        Me.CheckBox19.Text = "면포"
        Me.CheckBox19.UseVisualStyleBackColor = True
        '
        'CheckBox18
        '
        Me.CheckBox18.AutoSize = True
        Me.CheckBox18.Location = New System.Drawing.Point(109, 190)
        Me.CheckBox18.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox18.Name = "CheckBox18"
        Me.CheckBox18.Size = New System.Drawing.Size(74, 19)
        Me.CheckBox18.TabIndex = 17
        Me.CheckBox18.Text = "만성피로"
        Me.CheckBox18.UseVisualStyleBackColor = True
        '
        'CheckBox17
        '
        Me.CheckBox17.AutoSize = True
        Me.CheckBox17.Location = New System.Drawing.Point(109, 162)
        Me.CheckBox17.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox17.Name = "CheckBox17"
        Me.CheckBox17.Size = New System.Drawing.Size(50, 19)
        Me.CheckBox17.TabIndex = 16
        Me.CheckBox17.Text = "딱지"
        Me.CheckBox17.UseVisualStyleBackColor = True
        '
        'CheckBox16
        '
        Me.CheckBox16.AutoSize = True
        Me.CheckBox16.Location = New System.Drawing.Point(109, 135)
        Me.CheckBox16.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox16.Name = "CheckBox16"
        Me.CheckBox16.Size = New System.Drawing.Size(50, 19)
        Me.CheckBox16.TabIndex = 15
        Me.CheckBox16.Text = "두통"
        Me.CheckBox16.UseVisualStyleBackColor = True
        '
        'CheckBox15
        '
        Me.CheckBox15.AutoSize = True
        Me.CheckBox15.Location = New System.Drawing.Point(109, 108)
        Me.CheckBox15.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox15.Name = "CheckBox15"
        Me.CheckBox15.Size = New System.Drawing.Size(74, 19)
        Me.CheckBox15.TabIndex = 14
        Me.CheckBox15.Text = "두드러기"
        Me.CheckBox15.UseVisualStyleBackColor = True
        '
        'CheckBox14
        '
        Me.CheckBox14.AutoSize = True
        Me.CheckBox14.Location = New System.Drawing.Point(109, 80)
        Me.CheckBox14.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox14.Name = "CheckBox14"
        Me.CheckBox14.Size = New System.Drawing.Size(62, 19)
        Me.CheckBox14.TabIndex = 13
        Me.CheckBox14.Text = "눈부심"
        Me.CheckBox14.UseVisualStyleBackColor = True
        '
        'CheckBox13
        '
        Me.CheckBox13.AutoSize = True
        Me.CheckBox13.Location = New System.Drawing.Point(109, 52)
        Me.CheckBox13.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox13.Name = "CheckBox13"
        Me.CheckBox13.Size = New System.Drawing.Size(50, 19)
        Me.CheckBox13.TabIndex = 12
        Me.CheckBox13.Text = "농포"
        Me.CheckBox13.UseVisualStyleBackColor = True
        '
        'CheckBox12
        '
        Me.CheckBox12.AutoSize = True
        Me.CheckBox12.Location = New System.Drawing.Point(109, 25)
        Me.CheckBox12.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox12.Name = "CheckBox12"
        Me.CheckBox12.Size = New System.Drawing.Size(50, 19)
        Me.CheckBox12.TabIndex = 11
        Me.CheckBox12.Text = "낭종"
        Me.CheckBox12.UseVisualStyleBackColor = True
        '
        'CheckBox11
        '
        Me.CheckBox11.AutoSize = True
        Me.CheckBox11.Location = New System.Drawing.Point(16, 300)
        Me.CheckBox11.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox11.Name = "CheckBox11"
        Me.CheckBox11.Size = New System.Drawing.Size(50, 19)
        Me.CheckBox11.TabIndex = 10
        Me.CheckBox11.Text = "난청"
        Me.CheckBox11.UseVisualStyleBackColor = True
        '
        'CheckBox10
        '
        Me.CheckBox10.AutoSize = True
        Me.CheckBox10.Location = New System.Drawing.Point(16, 272)
        Me.CheckBox10.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox10.Name = "CheckBox10"
        Me.CheckBox10.Size = New System.Drawing.Size(50, 19)
        Me.CheckBox10.TabIndex = 9
        Me.CheckBox10.Text = "기침"
        Me.CheckBox10.UseVisualStyleBackColor = True
        '
        'CheckBox9
        '
        Me.CheckBox9.AutoSize = True
        Me.CheckBox9.Location = New System.Drawing.Point(16, 245)
        Me.CheckBox9.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox9.Name = "CheckBox9"
        Me.CheckBox9.Size = New System.Drawing.Size(62, 19)
        Me.CheckBox9.TabIndex = 8
        Me.CheckBox9.Text = "근육통"
        Me.CheckBox9.UseVisualStyleBackColor = True
        '
        'CheckBox8
        '
        Me.CheckBox8.AutoSize = True
        Me.CheckBox8.Location = New System.Drawing.Point(16, 218)
        Me.CheckBox8.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox8.Name = "CheckBox8"
        Me.CheckBox8.Size = New System.Drawing.Size(62, 19)
        Me.CheckBox8.TabIndex = 7
        Me.CheckBox8.Text = "권태감"
        Me.CheckBox8.UseVisualStyleBackColor = True
        '
        'CheckBox7
        '
        Me.CheckBox7.AutoSize = True
        Me.CheckBox7.Location = New System.Drawing.Point(16, 190)
        Me.CheckBox7.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox7.Name = "CheckBox7"
        Me.CheckBox7.Size = New System.Drawing.Size(50, 19)
        Me.CheckBox7.TabIndex = 6
        Me.CheckBox7.Text = "구토"
        Me.CheckBox7.UseVisualStyleBackColor = True
        '
        'CheckBox6
        '
        Me.CheckBox6.AutoSize = True
        Me.CheckBox6.Location = New System.Drawing.Point(16, 162)
        Me.CheckBox6.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox6.Name = "CheckBox6"
        Me.CheckBox6.Size = New System.Drawing.Size(50, 19)
        Me.CheckBox6.TabIndex = 5
        Me.CheckBox6.Text = "구취"
        Me.CheckBox6.UseVisualStyleBackColor = True
        '
        'CheckBox5
        '
        Me.CheckBox5.AutoSize = True
        Me.CheckBox5.Location = New System.Drawing.Point(16, 135)
        Me.CheckBox5.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox5.Name = "CheckBox5"
        Me.CheckBox5.Size = New System.Drawing.Size(62, 19)
        Me.CheckBox5.TabIndex = 4
        Me.CheckBox5.Text = "관절통"
        Me.CheckBox5.UseVisualStyleBackColor = True
        '
        'CheckBox4
        '
        Me.CheckBox4.AutoSize = True
        Me.CheckBox4.Location = New System.Drawing.Point(16, 108)
        Me.CheckBox4.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox4.Name = "CheckBox4"
        Me.CheckBox4.Size = New System.Drawing.Size(50, 19)
        Me.CheckBox4.TabIndex = 3
        Me.CheckBox4.Text = "결절"
        Me.CheckBox4.UseVisualStyleBackColor = True
        '
        'CheckBox3
        '
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.Location = New System.Drawing.Point(16, 80)
        Me.CheckBox3.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(50, 19)
        Me.CheckBox3.TabIndex = 2
        Me.CheckBox3.Text = "객혈"
        Me.CheckBox3.UseVisualStyleBackColor = True
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Location = New System.Drawing.Point(16, 52)
        Me.CheckBox2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(50, 19)
        Me.CheckBox2.TabIndex = 1
        Me.CheckBox2.Text = "객담"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(16, 25)
        Me.CheckBox1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(74, 19)
        Me.CheckBox1.TabIndex = 0
        Me.CheckBox1.Text = "가려움증"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'GroupBox_MedicalHistory
        '
        Me.GroupBox_MedicalHistory.Controls.Add(Me.CheckBox_His11)
        Me.GroupBox_MedicalHistory.Controls.Add(Me.CheckBox_His10)
        Me.GroupBox_MedicalHistory.Controls.Add(Me.CheckBox_His09)
        Me.GroupBox_MedicalHistory.Controls.Add(Me.CheckBox_His08)
        Me.GroupBox_MedicalHistory.Controls.Add(Me.CheckBox_His07)
        Me.GroupBox_MedicalHistory.Controls.Add(Me.CheckBox_His06)
        Me.GroupBox_MedicalHistory.Controls.Add(Me.CheckBox_His05)
        Me.GroupBox_MedicalHistory.Controls.Add(Me.CheckBox_His04)
        Me.GroupBox_MedicalHistory.Controls.Add(Me.CheckBox_His03)
        Me.GroupBox_MedicalHistory.Controls.Add(Me.CheckBox_His02)
        Me.GroupBox_MedicalHistory.Controls.Add(Me.CheckBox_His01)
        Me.GroupBox_MedicalHistory.Location = New System.Drawing.Point(12, 261)
        Me.GroupBox_MedicalHistory.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_MedicalHistory.Name = "GroupBox_MedicalHistory"
        Me.GroupBox_MedicalHistory.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_MedicalHistory.Size = New System.Drawing.Size(475, 135)
        Me.GroupBox_MedicalHistory.TabIndex = 5
        Me.GroupBox_MedicalHistory.TabStop = False
        Me.GroupBox_MedicalHistory.Text = "과거 병력 종류"
        '
        'CheckBox_His11
        '
        Me.CheckBox_His11.AutoSize = True
        Me.CheckBox_His11.Location = New System.Drawing.Point(327, 81)
        Me.CheckBox_His11.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox_His11.Name = "CheckBox_His11"
        Me.CheckBox_His11.Size = New System.Drawing.Size(74, 19)
        Me.CheckBox_His11.TabIndex = 10
        Me.CheckBox_His11.Text = "피부질환"
        Me.CheckBox_His11.UseVisualStyleBackColor = True
        '
        'CheckBox_His10
        '
        Me.CheckBox_His10.AutoSize = True
        Me.CheckBox_His10.Location = New System.Drawing.Point(327, 54)
        Me.CheckBox_His10.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox_His10.Name = "CheckBox_His10"
        Me.CheckBox_His10.Size = New System.Drawing.Size(62, 19)
        Me.CheckBox_His10.TabIndex = 9
        Me.CheckBox_His10.Text = "신경학"
        Me.CheckBox_His10.UseVisualStyleBackColor = True
        '
        'CheckBox_His09
        '
        Me.CheckBox_His09.AutoSize = True
        Me.CheckBox_His09.Location = New System.Drawing.Point(327, 26)
        Me.CheckBox_His09.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox_His09.Name = "CheckBox_His09"
        Me.CheckBox_His09.Size = New System.Drawing.Size(74, 19)
        Me.CheckBox_His09.TabIndex = 8
        Me.CheckBox_His09.Text = "호흡기학"
        Me.CheckBox_His09.UseVisualStyleBackColor = True
        '
        'CheckBox_His08
        '
        Me.CheckBox_His08.AutoSize = True
        Me.CheckBox_His08.Location = New System.Drawing.Point(185, 108)
        Me.CheckBox_His08.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox_His08.Name = "CheckBox_His08"
        Me.CheckBox_His08.Size = New System.Drawing.Size(86, 19)
        Me.CheckBox_His08.TabIndex = 7
        Me.CheckBox_His08.Text = "혈액종양학"
        Me.CheckBox_His08.UseVisualStyleBackColor = True
        '
        'CheckBox_His07
        '
        Me.CheckBox_His07.AutoSize = True
        Me.CheckBox_His07.Location = New System.Drawing.Point(185, 81)
        Me.CheckBox_His07.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox_His07.Name = "CheckBox_His07"
        Me.CheckBox_His07.Size = New System.Drawing.Size(86, 19)
        Me.CheckBox_His07.TabIndex = 6
        Me.CheckBox_His07.Text = "알레르기학"
        Me.CheckBox_His07.UseVisualStyleBackColor = True
        '
        'CheckBox_His06
        '
        Me.CheckBox_His06.AutoSize = True
        Me.CheckBox_His06.Location = New System.Drawing.Point(185, 54)
        Me.CheckBox_His06.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox_His06.Name = "CheckBox_His06"
        Me.CheckBox_His06.Size = New System.Drawing.Size(62, 19)
        Me.CheckBox_His06.TabIndex = 5
        Me.CheckBox_His06.Text = "신장학"
        Me.CheckBox_His06.UseVisualStyleBackColor = True
        '
        'CheckBox_His05
        '
        Me.CheckBox_His05.AutoSize = True
        Me.CheckBox_His05.Location = New System.Drawing.Point(185, 26)
        Me.CheckBox_His05.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox_His05.Name = "CheckBox_His05"
        Me.CheckBox_His05.Size = New System.Drawing.Size(74, 19)
        Me.CheckBox_His05.TabIndex = 4
        Me.CheckBox_His05.Text = "순환기학"
        Me.CheckBox_His05.UseVisualStyleBackColor = True
        '
        'CheckBox_His04
        '
        Me.CheckBox_His04.AutoSize = True
        Me.CheckBox_His04.Location = New System.Drawing.Point(52, 109)
        Me.CheckBox_His04.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox_His04.Name = "CheckBox_His04"
        Me.CheckBox_His04.Size = New System.Drawing.Size(74, 19)
        Me.CheckBox_His04.TabIndex = 3
        Me.CheckBox_His04.Text = "소화기학"
        Me.CheckBox_His04.UseVisualStyleBackColor = True
        '
        'CheckBox_His03
        '
        Me.CheckBox_His03.AutoSize = True
        Me.CheckBox_His03.Location = New System.Drawing.Point(52, 81)
        Me.CheckBox_His03.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox_His03.Name = "CheckBox_His03"
        Me.CheckBox_His03.Size = New System.Drawing.Size(86, 19)
        Me.CheckBox_His03.TabIndex = 2
        Me.CheckBox_His03.Text = "류마티스학"
        Me.CheckBox_His03.UseVisualStyleBackColor = True
        '
        'CheckBox_His02
        '
        Me.CheckBox_His02.AutoSize = True
        Me.CheckBox_His02.Location = New System.Drawing.Point(52, 54)
        Me.CheckBox_His02.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox_His02.Name = "CheckBox_His02"
        Me.CheckBox_His02.Size = New System.Drawing.Size(74, 19)
        Me.CheckBox_His02.TabIndex = 1
        Me.CheckBox_His02.Text = "내분비학"
        Me.CheckBox_His02.UseVisualStyleBackColor = True
        '
        'CheckBox_His01
        '
        Me.CheckBox_His01.AutoSize = True
        Me.CheckBox_His01.Location = New System.Drawing.Point(52, 26)
        Me.CheckBox_His01.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox_His01.Name = "CheckBox_His01"
        Me.CheckBox_His01.Size = New System.Drawing.Size(62, 19)
        Me.CheckBox_His01.TabIndex = 0
        Me.CheckBox_His01.Text = "감염학"
        Me.CheckBox_His01.UseVisualStyleBackColor = True
        '
        'GroupBox_Medicine
        '
        Me.GroupBox_Medicine.Controls.Add(Me.CheckBox_Medi11)
        Me.GroupBox_Medicine.Controls.Add(Me.CheckBox_Medi10)
        Me.GroupBox_Medicine.Controls.Add(Me.CheckBox_Medi09)
        Me.GroupBox_Medicine.Controls.Add(Me.CheckBox_Medi08)
        Me.GroupBox_Medicine.Controls.Add(Me.CheckBox_Medi07)
        Me.GroupBox_Medicine.Controls.Add(Me.CheckBox_Medi06)
        Me.GroupBox_Medicine.Controls.Add(Me.CheckBox_Medi05)
        Me.GroupBox_Medicine.Controls.Add(Me.CheckBox_Medi04)
        Me.GroupBox_Medicine.Controls.Add(Me.CheckBox_Medi03)
        Me.GroupBox_Medicine.Controls.Add(Me.CheckBox_Medi02)
        Me.GroupBox_Medicine.Controls.Add(Me.CheckBox_Medi01)
        Me.GroupBox_Medicine.Location = New System.Drawing.Point(12, 404)
        Me.GroupBox_Medicine.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_Medicine.Name = "GroupBox_Medicine"
        Me.GroupBox_Medicine.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_Medicine.Size = New System.Drawing.Size(475, 135)
        Me.GroupBox_Medicine.TabIndex = 6
        Me.GroupBox_Medicine.TabStop = False
        Me.GroupBox_Medicine.Text = "현재 투약중인 약 종류"
        '
        'CheckBox_Medi11
        '
        Me.CheckBox_Medi11.AutoSize = True
        Me.CheckBox_Medi11.Location = New System.Drawing.Point(327, 80)
        Me.CheckBox_Medi11.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox_Medi11.Name = "CheckBox_Medi11"
        Me.CheckBox_Medi11.Size = New System.Drawing.Size(74, 19)
        Me.CheckBox_Medi11.TabIndex = 10
        Me.CheckBox_Medi11.Text = "피부질환"
        Me.CheckBox_Medi11.UseVisualStyleBackColor = True
        '
        'CheckBox_Medi10
        '
        Me.CheckBox_Medi10.AutoSize = True
        Me.CheckBox_Medi10.Location = New System.Drawing.Point(327, 52)
        Me.CheckBox_Medi10.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox_Medi10.Name = "CheckBox_Medi10"
        Me.CheckBox_Medi10.Size = New System.Drawing.Size(62, 19)
        Me.CheckBox_Medi10.TabIndex = 9
        Me.CheckBox_Medi10.Text = "신경학"
        Me.CheckBox_Medi10.UseVisualStyleBackColor = True
        '
        'CheckBox_Medi09
        '
        Me.CheckBox_Medi09.AutoSize = True
        Me.CheckBox_Medi09.Location = New System.Drawing.Point(327, 25)
        Me.CheckBox_Medi09.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox_Medi09.Name = "CheckBox_Medi09"
        Me.CheckBox_Medi09.Size = New System.Drawing.Size(74, 19)
        Me.CheckBox_Medi09.TabIndex = 8
        Me.CheckBox_Medi09.Text = "호흡기학"
        Me.CheckBox_Medi09.UseVisualStyleBackColor = True
        '
        'CheckBox_Medi08
        '
        Me.CheckBox_Medi08.AutoSize = True
        Me.CheckBox_Medi08.Location = New System.Drawing.Point(185, 109)
        Me.CheckBox_Medi08.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox_Medi08.Name = "CheckBox_Medi08"
        Me.CheckBox_Medi08.Size = New System.Drawing.Size(86, 19)
        Me.CheckBox_Medi08.TabIndex = 7
        Me.CheckBox_Medi08.Text = "혈액종양학"
        Me.CheckBox_Medi08.UseVisualStyleBackColor = True
        '
        'CheckBox_Medi07
        '
        Me.CheckBox_Medi07.AutoSize = True
        Me.CheckBox_Medi07.Location = New System.Drawing.Point(185, 81)
        Me.CheckBox_Medi07.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox_Medi07.Name = "CheckBox_Medi07"
        Me.CheckBox_Medi07.Size = New System.Drawing.Size(86, 19)
        Me.CheckBox_Medi07.TabIndex = 6
        Me.CheckBox_Medi07.Text = "알레르기학"
        Me.CheckBox_Medi07.UseVisualStyleBackColor = True
        '
        'CheckBox_Medi06
        '
        Me.CheckBox_Medi06.AutoSize = True
        Me.CheckBox_Medi06.Location = New System.Drawing.Point(185, 54)
        Me.CheckBox_Medi06.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox_Medi06.Name = "CheckBox_Medi06"
        Me.CheckBox_Medi06.Size = New System.Drawing.Size(62, 19)
        Me.CheckBox_Medi06.TabIndex = 5
        Me.CheckBox_Medi06.Text = "신장학"
        Me.CheckBox_Medi06.UseVisualStyleBackColor = True
        '
        'CheckBox_Medi05
        '
        Me.CheckBox_Medi05.AutoSize = True
        Me.CheckBox_Medi05.Location = New System.Drawing.Point(185, 26)
        Me.CheckBox_Medi05.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox_Medi05.Name = "CheckBox_Medi05"
        Me.CheckBox_Medi05.Size = New System.Drawing.Size(74, 19)
        Me.CheckBox_Medi05.TabIndex = 4
        Me.CheckBox_Medi05.Text = "순환기학"
        Me.CheckBox_Medi05.UseVisualStyleBackColor = True
        '
        'CheckBox_Medi04
        '
        Me.CheckBox_Medi04.AutoSize = True
        Me.CheckBox_Medi04.Location = New System.Drawing.Point(52, 109)
        Me.CheckBox_Medi04.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox_Medi04.Name = "CheckBox_Medi04"
        Me.CheckBox_Medi04.Size = New System.Drawing.Size(74, 19)
        Me.CheckBox_Medi04.TabIndex = 3
        Me.CheckBox_Medi04.Text = "소화기학"
        Me.CheckBox_Medi04.UseVisualStyleBackColor = True
        '
        'CheckBox_Medi03
        '
        Me.CheckBox_Medi03.AutoSize = True
        Me.CheckBox_Medi03.Location = New System.Drawing.Point(52, 81)
        Me.CheckBox_Medi03.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox_Medi03.Name = "CheckBox_Medi03"
        Me.CheckBox_Medi03.Size = New System.Drawing.Size(86, 19)
        Me.CheckBox_Medi03.TabIndex = 2
        Me.CheckBox_Medi03.Text = "류마티스학"
        Me.CheckBox_Medi03.UseVisualStyleBackColor = True
        '
        'CheckBox_Medi02
        '
        Me.CheckBox_Medi02.AutoSize = True
        Me.CheckBox_Medi02.Location = New System.Drawing.Point(52, 54)
        Me.CheckBox_Medi02.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox_Medi02.Name = "CheckBox_Medi02"
        Me.CheckBox_Medi02.Size = New System.Drawing.Size(74, 19)
        Me.CheckBox_Medi02.TabIndex = 1
        Me.CheckBox_Medi02.Text = "내분비학"
        Me.CheckBox_Medi02.UseVisualStyleBackColor = True
        '
        'CheckBox_Medi01
        '
        Me.CheckBox_Medi01.AutoSize = True
        Me.CheckBox_Medi01.Location = New System.Drawing.Point(52, 26)
        Me.CheckBox_Medi01.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBox_Medi01.Name = "CheckBox_Medi01"
        Me.CheckBox_Medi01.Size = New System.Drawing.Size(62, 19)
        Me.CheckBox_Medi01.TabIndex = 0
        Me.CheckBox_Medi01.Text = "감염학"
        Me.CheckBox_Medi01.UseVisualStyleBackColor = True
        '
        'Form_Input
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(984, 551)
        Me.Controls.Add(Me.GroupBox_Medicine)
        Me.Controls.Add(Me.GroupBox_MedicalHistory)
        Me.Controls.Add(Me.GroupBox_Symptom)
        Me.Controls.Add(Me.GroupBox_Pregnancy)
        Me.Controls.Add(Me.GroupBox_Person)
        Me.Controls.Add(Me.Button_OK)
        Me.Font = New System.Drawing.Font("맑은 고딕", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MaximizeBox = False
        Me.Name = "Form_Input"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Medinology"
        Me.GroupBox_Person.ResumeLayout(False)
        Me.GroupBox_Person.PerformLayout()
        CType(Me.NumericUpDown_Age, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Pregnancy.ResumeLayout(False)
        Me.GroupBox_Pregnancy.PerformLayout()
        Me.GroupBox_Symptom.ResumeLayout(False)
        Me.GroupBox_Symptom.PerformLayout()
        Me.GroupBox_MedicalHistory.ResumeLayout(False)
        Me.GroupBox_MedicalHistory.PerformLayout()
        Me.GroupBox_Medicine.ResumeLayout(False)
        Me.GroupBox_Medicine.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Button_OK As Button
    Friend WithEvents GroupBox_Person As GroupBox
    Friend WithEvents Label_Age2 As Label
    Friend WithEvents NumericUpDown_Age As NumericUpDown
    Friend WithEvents Label_Age As Label
    Friend WithEvents RadioButton_Female As RadioButton
    Friend WithEvents Label_Gender As Label
    Friend WithEvents RadioButton_Male As RadioButton
    Friend WithEvents GroupBox_Pregnancy As GroupBox
    Friend WithEvents RadioButton_PregF As RadioButton
    Friend WithEvents RadioButton_PregT As RadioButton
    Friend WithEvents GroupBox_Symptom As GroupBox
    Friend WithEvents CheckBox51 As CheckBox
    Friend WithEvents CheckBox50 As CheckBox
    Friend WithEvents CheckBox49 As CheckBox
    Friend WithEvents CheckBox48 As CheckBox
    Friend WithEvents CheckBox47 As CheckBox
    Friend WithEvents CheckBox46 As CheckBox
    Friend WithEvents CheckBox45 As CheckBox
    Friend WithEvents CheckBox44 As CheckBox
    Friend WithEvents CheckBox43 As CheckBox
    Friend WithEvents CheckBox42 As CheckBox
    Friend WithEvents CheckBox41 As CheckBox
    Friend WithEvents CheckBox40 As CheckBox
    Friend WithEvents CheckBox39 As CheckBox
    Friend WithEvents CheckBox38 As CheckBox
    Friend WithEvents CheckBox37 As CheckBox
    Friend WithEvents CheckBox36 As CheckBox
    Friend WithEvents CheckBox35 As CheckBox
    Friend WithEvents CheckBox34 As CheckBox
    Friend WithEvents CheckBox33 As CheckBox
    Friend WithEvents CheckBox32 As CheckBox
    Friend WithEvents CheckBox31 As CheckBox
    Friend WithEvents CheckBox30 As CheckBox
    Friend WithEvents CheckBox29 As CheckBox
    Friend WithEvents CheckBox28 As CheckBox
    Friend WithEvents CheckBox27 As CheckBox
    Friend WithEvents CheckBox26 As CheckBox
    Friend WithEvents CheckBox25 As CheckBox
    Friend WithEvents CheckBox24 As CheckBox
    Friend WithEvents CheckBox23 As CheckBox
    Friend WithEvents CheckBox22 As CheckBox
    Friend WithEvents CheckBox21 As CheckBox
    Friend WithEvents CheckBox20 As CheckBox
    Friend WithEvents CheckBox19 As CheckBox
    Friend WithEvents CheckBox18 As CheckBox
    Friend WithEvents CheckBox17 As CheckBox
    Friend WithEvents CheckBox16 As CheckBox
    Friend WithEvents CheckBox15 As CheckBox
    Friend WithEvents CheckBox14 As CheckBox
    Friend WithEvents CheckBox13 As CheckBox
    Friend WithEvents CheckBox12 As CheckBox
    Friend WithEvents CheckBox11 As CheckBox
    Friend WithEvents CheckBox10 As CheckBox
    Friend WithEvents CheckBox9 As CheckBox
    Friend WithEvents CheckBox8 As CheckBox
    Friend WithEvents CheckBox7 As CheckBox
    Friend WithEvents CheckBox6 As CheckBox
    Friend WithEvents CheckBox5 As CheckBox
    Friend WithEvents CheckBox4 As CheckBox
    Friend WithEvents CheckBox3 As CheckBox
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents GroupBox_MedicalHistory As GroupBox
    Friend WithEvents CheckBox_His04 As CheckBox
    Friend WithEvents CheckBox_His03 As CheckBox
    Friend WithEvents CheckBox_His02 As CheckBox
    Friend WithEvents CheckBox_His01 As CheckBox
    Friend WithEvents CheckBox_His11 As CheckBox
    Friend WithEvents CheckBox_His10 As CheckBox
    Friend WithEvents CheckBox_His09 As CheckBox
    Friend WithEvents CheckBox_His08 As CheckBox
    Friend WithEvents CheckBox_His07 As CheckBox
    Friend WithEvents CheckBox_His06 As CheckBox
    Friend WithEvents CheckBox_His05 As CheckBox
    Friend WithEvents GroupBox_Medicine As GroupBox
    Friend WithEvents CheckBox_Medi11 As CheckBox
    Friend WithEvents CheckBox_Medi10 As CheckBox
    Friend WithEvents CheckBox_Medi09 As CheckBox
    Friend WithEvents CheckBox_Medi08 As CheckBox
    Friend WithEvents CheckBox_Medi07 As CheckBox
    Friend WithEvents CheckBox_Medi06 As CheckBox
    Friend WithEvents CheckBox_Medi05 As CheckBox
    Friend WithEvents CheckBox_Medi04 As CheckBox
    Friend WithEvents CheckBox_Medi03 As CheckBox
    Friend WithEvents CheckBox_Medi02 As CheckBox
    Friend WithEvents CheckBox_Medi01 As CheckBox
End Class
