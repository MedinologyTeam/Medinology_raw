/** Automatically generated file. DO NOT MODIFY */
package com.kyunggi.medinology;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}